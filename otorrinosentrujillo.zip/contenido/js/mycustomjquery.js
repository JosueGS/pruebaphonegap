$(document).ready(function(){
    
    /*=====================Slider Principal ==========================*/
    $(".slide_principal").slick({
        dots: false,
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay:false,
        autoplaySpeed:3000,
        arrows:true,
        responsive: [

            {

                breakpoint: 576,

                settings: {

                    arrows: false,
                }

            },
        ]
    });
     /*=====================Slider Principal-2 ==========================*/
     $(".slide_principal_2").slick({
        dots: false,
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay:false,
        autoplaySpeed:3000,
        arrows:true,
        responsive: [

            {

                breakpoint: 576,

                settings: {

                    arrows: false,
                }

            },
        ]
    });

    /*=====================Slider Photos ==========================*/
    $(".slide_gamer").slick({
        dots: false,
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay:false,
        arrows:true
    });

    /*=====================Slider con más de un items==========================*/
    $(".slide-marcas").slick(
        {

        arrows: true,

        dots: false,

        infinite: true,

        slidesToShow: 5,

        // slidesToScroll: 1,

        speed: 1000,

        autoplaySpeed: 2000,

        autoplay: true,

        respondTo: 'window',

        mobileFirst: true,

        responsive: [

            {

                breakpoint: 1080,

                settings: {

                    slidesToShow: 5,

                    // slidesToScroll: 1

                }

            },

            {

                breakpoint: 991,

                settings: {

                    slidesToShow: 3,

                    // slidesToScroll: 1

                }

            },
            {

                breakpoint: 820,

                settings: {

                    slidesToShow: 5,

                    // slidesToScroll: 1

                }

            },

            {

                breakpoint: 769,

                settings: {

                    slidesToShow: 5,

                    // slidesToScroll: 1

                }

            },

            {

                breakpoint: 690,

                settings: {

                    slidesToShow: 4,

                    // slidesToScroll: 1

                }

            },

            {

                breakpoint: 620,

                settings: {

                    slidesToShow: 4,

                    // slidesToScroll: 1

                }

            },

            {

                breakpoint: 480,

                settings: {

                    slidesToShow: 3,

                    // slidesToScroll: 1

                }

            },

            {

                breakpoint: 300,

                settings: {

                    slidesToShow: 2,

                    // slidesToScroll: 1

                }

            },
            {

                breakpoint: 277,

                settings: {

                    slidesToShow: 1,

                    // slidesToScroll: 1

                }

            }

        ]

    })
    
    /*===============Parallax====================*/
    $(window).scroll(function(){
        var barra = $(window).scrollTop();
        var posicion =  (barra * 0.50);

        $('.contenedorParallax').css({
            'background-position': '0 -' + posicion + 'px',
        });
    })

    /*===================Sky====================*/
    $('.arribair').click(function(){
            $('body,html').animate({
                scrollTop: '0px'
            },2000);
        });
    $(window).scroll(function(){
        if ($(this).scrollTop() > 0){
            $('.arribair').slideDown(500);
        }else{
            $('.arribair').slideUp(500);
        }
    });

})

